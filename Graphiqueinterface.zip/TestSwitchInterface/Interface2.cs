﻿using System.Windows.Forms;

namespace InterfaceSwitcherWinForms
{
    public partial class Interface2 : UserControl
    {
        public Interface2()
        {
            InitializeComponent();
        }
    }
}
