///////////////////////////////////////////////////////////
//  CFiles.cpp
//  Implementation of the Class CFiles
//  Created on:      26-mars-2025 15:05:34
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CFiles.h"
#include <iostream>
#include <fstream>
using namespace std;

CFiles::CFiles():IDStream(-1),FileName1("") {

}



CFiles::~CFiles() {
	
}





void CFiles::ecrire(int IDStream) {
   
    ofstream file(FileName1, ios::app); // Mode append pour ajouter du contenu sans �craser
    if (file.is_open()) {
        file << IDStream << endl;
        cout << "�criture r�ussie dans le fichier." << endl;
        file.close();
    }
    else {
        cerr << "Impossible d'ouvrir le fichier pour l'�criture." << endl;
    }
}


void CFiles::fermer(int IDStream){

	
}


void CFiles::lire(int IDStraem){
    ifstream file(FileName1);
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            cout << line << std::endl;
        }
        file.close();
    }
    else {
        std::cerr << "Impossible d'ouvrir le fichier pour la lecture." << std::endl;
    }
}



void CFiles::ouvrir(string FileName){
    this->FileName1 = FileName;
    ifstream file(FileName);
    if (file.is_open()) {
        std::cout << "Fichier ouvert avec succ�s." << std::endl;
        file.close();
    }
    else {
        std::cerr << "Impossible d'ouvrir le fichier." << std::endl;
    }
	 
}
