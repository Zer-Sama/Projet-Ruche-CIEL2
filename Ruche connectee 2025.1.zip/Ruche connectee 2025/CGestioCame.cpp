///////////////////////////////////////////////////////////
//  CGestioCame.cpp
//  Implementation of the Class CGestioCame
//  Created on:      30-avr.-2025 13:08:47
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CGestioCame.h"


CGestioCame::CGestioCame(){

}



CGestioCame::~CGestioCame(){

}





boolean CGestioCame::FiltrerLesCouleur(){

	return  NULL;
}


Mat CGestioCame::PrendreUnePhoto(){

	return  NULL;
}