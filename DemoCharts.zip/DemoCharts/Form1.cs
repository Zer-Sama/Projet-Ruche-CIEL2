﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace DemoCharts
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void InitializeChart()
        {
            double y;
            // Nettoie l'ancien contenu
            chart1.Series.Clear();
            chart1.ChartAreas.Clear();

            // Crée une zone de graphique
            ChartArea chartArea = new ChartArea("MainArea");
            chart1.ChartAreas.Add(chartArea);

            // Crée la série et configure son type
            Series series = new Series("Valeurs");
            series.ChartType = SeriesChartType.Line;

            // Ajoute des points à la série
            for (int i = 0; i < 720; i++)
            {
                y = 6.28 * i / 360.0;
                series.Points.AddXY(i, Math.Sin(y));
            }

            // Ajoute la série au graphique
            chart1.Series.Add(series);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InitializeChart();
        }
    }
}
