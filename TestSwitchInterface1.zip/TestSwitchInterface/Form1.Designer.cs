﻿namespace InterfaceSwitcherWinForms
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel InterfaceContainer;
        private System.Windows.Forms.Button SwitchToInterface1;
        private System.Windows.Forms.Button SwitchToInterface2;

        private void InitializeComponent()
        {
            SwitchToInterface1 = new Button();
            SwitchToInterface2 = new Button();
            InterfaceContainer = new Panel();
            SuspendLayout();
            // 
            // SwitchToInterface1
            // 
            SwitchToInterface1.Location = new Point(12, 12);
            SwitchToInterface1.Name = "SwitchToInterface1";
            SwitchToInterface1.Size = new Size(150, 23);
            SwitchToInterface1.TabIndex = 0;
            SwitchToInterface1.Text = "Switch to Interface 1";
            SwitchToInterface1.UseVisualStyleBackColor = true;
            SwitchToInterface1.Click += SwitchToInterface1_Click;
            // 
            // SwitchToInterface2
            // 
            SwitchToInterface2.Location = new Point(170, 12);
            SwitchToInterface2.Name = "SwitchToInterface2";
            SwitchToInterface2.Size = new Size(150, 23);
            SwitchToInterface2.TabIndex = 1;
            SwitchToInterface2.Text = "Switch to Interface 2";
            SwitchToInterface2.UseVisualStyleBackColor = true;
            SwitchToInterface2.Click += SwitchToInterface2_Click;
            // 
            // InterfaceContainer
            // 
            InterfaceContainer.Location = new Point(12, 41);
            InterfaceContainer.Name = "InterfaceContainer";
            InterfaceContainer.Size = new Size(1242, 521);
            InterfaceContainer.TabIndex = 2;
            // 
            // Form1
            // 
            ClientSize = new Size(1266, 583);
            Controls.Add(InterfaceContainer);
            Controls.Add(SwitchToInterface2);
            Controls.Add(SwitchToInterface1);
            Name = "Form1";
            ResumeLayout(false);
        }
    }
}

