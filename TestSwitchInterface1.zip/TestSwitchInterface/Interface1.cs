﻿using System.Windows.Forms;

namespace InterfaceSwitcherWinForms
{
    public partial class Interface1 : UserControl
    {
        public Interface1()
        {
            InitializeComponent();
        }
    }
}

