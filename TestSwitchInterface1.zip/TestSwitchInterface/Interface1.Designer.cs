﻿namespace InterfaceSwitcherWinForms
{
    partial class Interface1
    {
        private System.ComponentModel.IContainer components = null;

        private void InitializeComponent()
        {
            SuspendLayout();
            // 
            // Interface1
            // 
            Name = "Interface1";
            Size = new Size(1242, 521);
            ResumeLayout(false);
        }
    }
}
