﻿namespace InterfaceSwitcherWinForms
{
    partial class Interface2
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label label1;

        private void InitializeComponent()
        {
            label1 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(70, 90);
            label1.Name = "label1";
            label1.Size = new Size(134, 20);
            label1.TabIndex = 0;
            label1.Text = "This is Interface 2";
            // 
            // Interface2
            // 
            Controls.Add(label1);
            Name = "Interface2";
            Size = new Size(1242, 521);
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
