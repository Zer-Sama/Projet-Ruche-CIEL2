﻿namespace InterfaceSwitcherWinForms
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel InterfaceContainer;
        private System.Windows.Forms.Button SwitchToInterface1;
        private System.Windows.Forms.Button SwitchToInterface2;

        private void InitializeComponent()
        {
            this.SwitchToInterface1 = new System.Windows.Forms.Button();
            this.SwitchToInterface2 = new System.Windows.Forms.Button();
            this.InterfaceContainer = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            //
            // SwitchToInterface1
            //
            this.SwitchToInterface1.Location = new System.Drawing.Point(12, 12);
            this.SwitchToInterface1.Name = "SwitchToInterface1";
            this.SwitchToInterface1.Size = new System.Drawing.Size(150, 23);
            this.SwitchToInterface1.TabIndex = 0;
            this.SwitchToInterface1.Text = "Switch to Interface 1";
            this.SwitchToInterface1.UseVisualStyleBackColor = true;
            this.SwitchToInterface1.Click += new System.EventHandler(this.SwitchToInterface1_Click);
            //
            // SwitchToInterface2
            //
            this.SwitchToInterface2.Location = new System.Drawing.Point(170, 12);
            this.SwitchToInterface2.Name = "SwitchToInterface2";
            this.SwitchToInterface2.Size = new System.Drawing.Size(150, 23);
            this.SwitchToInterface2.TabIndex = 1;
            this.SwitchToInterface2.Text = "Switch to Interface 2";
            this.SwitchToInterface2.UseVisualStyleBackColor = true;
            this.SwitchToInterface2.Click += new System.EventHandler(this.SwitchToInterface2_Click);
            //
            // InterfaceContainer
            //
            this.InterfaceContainer.Location = new System.Drawing.Point(12, 41);
            this.InterfaceContainer.Name = "InterfaceContainer";
            this.InterfaceContainer.Size = new System.Drawing.Size(308, 207);
            this.InterfaceContainer.TabIndex = 2;
            //
            // Form1
            //
            this.ClientSize = new System.Drawing.Size(332, 260);
            this.Controls.Add(this.InterfaceContainer);
            this.Controls.Add(this.SwitchToInterface2);
            this.Controls.Add(this.SwitchToInterface1);
            this.Name = "Form1";
            this.ResumeLayout(false);
        }
    }
}

