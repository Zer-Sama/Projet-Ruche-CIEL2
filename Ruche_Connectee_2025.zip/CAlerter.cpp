///////////////////////////////////////////////////////////
//  CAlerter.cpp
//  Implementation of the Class CAlerter
//  Created on:      26-mars-2025 15:05:33
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CAlerter.h"


CAlerter::CAlerter(){

}



CAlerter::~CAlerter(){

}





CAlerter::connecter(){

}


CAlerter::ecrire(double DonneesCapteur, char DonneesCamera){

}