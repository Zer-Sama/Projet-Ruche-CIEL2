///////////////////////////////////////////////////////////
//  CServeur.h
//  Implementation of the Class CServeur
//  Created on:      26-mars-2025 15:05:34
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#if !defined(EA_E12360CD_B2E1_4b74_B75C_32C324138F3E__INCLUDED_)
#define EA_E12360CD_B2E1_4b74_B75C_32C324138F3E__INCLUDED_

class CServeur
{

public:
	CServeur();
	virtual ~CServeur();

	connecter(const string& 192.168.1.234, int 22);
	deconnecter();
	ecrire();
	Lire();
	start(int 22);

private:
	char Identifiant;
	char Mot de passe;

};
#endif // !defined(EA_E12360CD_B2E1_4b74_B75C_32C324138F3E__INCLUDED_)
