///////////////////////////////////////////////////////////
//  CFiles.cpp
//  Implementation of the Class CFiles
//  Created on:      26-mars-2025 15:05:34
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CFiles.h"


CFiles::CFiles(){

}



CFiles::~CFiles(){

}





CFiles::ecrire(){

}


int CFiles::fermer(int IDStream){

	return 0;
}


CFiles::lire(int IDStraem){

}


IDStream CFiles::ouvrir(){

	return  NULL;
}