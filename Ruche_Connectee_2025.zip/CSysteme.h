///////////////////////////////////////////////////////////
//  CSysteme.h
//  Implementation of the Class CSysteme
//  Created on:      26-mars-2025 15:05:35
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#if !defined(EA_66810725_71FC_4ecc_9432_505B2075A971__INCLUDED_)
#define EA_66810725_71FC_4ecc_9432_505B2075A971__INCLUDED_

#include "CAlerter.h"
#include "CDecrypte.h"
#include "CLecteurCapteur.h"
#include "CServeur.h"
#include "CFiles.h"

class CSysteme
{

public:
	CSysteme();
	virtual ~CSysteme();
	int IDStream;
	CAlerter *m_CAlerter;
	CDecrypte *m_CDecrypte;
	CLecteurCapteur *m_CLecteurCapteur;
	CServeur *m_CServeur;
	CFiles *m_CFiles;

	boolean comparer();
	Ecrire();
	ModifierParametre();
	int ; IDStream TraitementRequete();

private:
	double HygrometrieRef;
	double MasseRef;
	double TemperatureRef;

	int CAlerter();
	int ~CAlerter();
	CFiles(char Noms, char Emplacement);
	~CFiles();
	int CServeur();
	int ~CServeur();

};
#endif // !defined(EA_66810725_71FC_4ecc_9432_505B2075A971__INCLUDED_)
