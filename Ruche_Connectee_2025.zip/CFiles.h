///////////////////////////////////////////////////////////
//  CFiles.h
//  Implementation of the Class CFiles
//  Created on:      26-mars-2025 15:05:33
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#if !defined(EA_2A63CD98_346B_4a6c_A0B4_899AAFBCBAFE__INCLUDED_)
#define EA_2A63CD98_346B_4a6c_A0B4_899AAFBCBAFE__INCLUDED_

class CFiles
{

public:
	CFiles();
	virtual ~CFiles();

	ecrire();
	int fermer(int IDStream);
	lire(int IDStraem);
	IDStream ouvrir();

private:
	char FileName;

};
#endif // !defined(EA_2A63CD98_346B_4a6c_A0B4_899AAFBCBAFE__INCLUDED_)
