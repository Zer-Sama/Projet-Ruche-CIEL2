///////////////////////////////////////////////////////////
//  CServeur.cpp
//  Implementation of the Class CServeur
//  Created on:      26-mars-2025 15:05:35
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CServeur.h"


CServeur::CServeur(): adresseIP("192.168.1.234"), port(22) {
	std::cout << "Serveur est cr��." << std::endl;
}



CServeur::~CServeur(){
	if (!adresseIP.size()==0 {
		deconnecter();
	}
	std::cout << "Serveur d�truit." << std::endl;
}





CServeur::connecter(const std::string& adresseIP, int port){
	this->adresseIP = adresseIP;
	this->port = port;
	std::cout << "Connexion au serveur  " << adresseIP << ":" << port << std::endl;
	return true;
}


CServeur::deconnecter(){
	if (!adresseIP.size() == 0 {
	 {
		std::cout << "D�connexion du serveur " << adresseIP << ":" << port << std::endl;
}


CServeur::ecrire(){

}


CServeur::Lire(){

}


CServeur::start(int 22){
	std::cout << "D�marrage du serveur" << port << std::endl;
}