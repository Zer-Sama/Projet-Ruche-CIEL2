///////////////////////////////////////////////////////////
//  CSysteme.cpp
//  Implementation of the Class CSysteme
//  Created on:      26-mars-2025 15:05:35
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CSysteme.h"


CSysteme::CSysteme(){

}



CSysteme::~CSysteme(){

}





int CSysteme::CAlerter(){

	return 0;
}


int CSysteme::~CAlerter(){

	return 0;
}


CSysteme::CFiles(char Noms, char Emplacement){

}


CSysteme::~CFiles(){

}


boolean CSysteme::comparer(){

	return  NULL;
}


int CSysteme::CServeur(){

	return 0;
}


int CSysteme::~CServeur(){

	return 0;
}


CSysteme::Ecrire(){

}


CSysteme::ModifierParametre(){

}


int ; IDStream CSysteme::TraitementRequete(){

	return  NULL;
}