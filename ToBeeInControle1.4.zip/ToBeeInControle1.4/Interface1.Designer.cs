﻿namespace ToBeeInControleWinForms
{
    partial class Interface1
    {
        private System.ComponentModel.IContainer components = null;

        private void InitializeComponent()
        {
            pictureBoxGraphTemperature = new PictureBox();
            pictureBoxGraphHygro = new PictureBox();
            pictureBoxGraphmasse = new PictureBox();
            listBox1 = new ListBox();
            labelDateDebut = new Label();
            labelDateFin = new Label();
            dataGridViewPassagesReines = new DataGridView();
            Date = new DataGridViewTextBoxColumn();
            Couleur = new DataGridViewTextBoxColumn();
            dataGridViewPosition = new DataGridView();
            Horodatage = new DataGridViewTextBoxColumn();
            Coordonnées = new DataGridViewTextBoxColumn();
            textBoxPosition = new TextBox();
            textBoxPassagesReines = new TextBox();
            buttonAppliquer = new Button();
            maskedTextBoxDateDebut = new MaskedTextBox();
            maskedTextBoxDateFin = new MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphTemperature).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphHygro).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphmasse).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPassagesReines).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPosition).BeginInit();
            SuspendLayout();
            // 
            // pictureBoxGraphTemperature
            // 
            pictureBoxGraphTemperature.Location = new Point(130, 30);
            pictureBoxGraphTemperature.Name = "pictureBoxGraphTemperature";
            pictureBoxGraphTemperature.Size = new Size(550, 550);
            pictureBoxGraphTemperature.TabIndex = 0;
            pictureBoxGraphTemperature.TabStop = false;
            // 
            // pictureBoxGraphHygro
            // 
            pictureBoxGraphHygro.Location = new Point(700, 30);
            pictureBoxGraphHygro.Name = "pictureBoxGraphHygro";
            pictureBoxGraphHygro.Size = new Size(550, 550);
            pictureBoxGraphHygro.TabIndex = 1;
            pictureBoxGraphHygro.TabStop = false;
            // 
            // pictureBoxGraphmasse
            // 
            pictureBoxGraphmasse.Location = new Point(1270, 30);
            pictureBoxGraphmasse.Name = "pictureBoxGraphmasse";
            pictureBoxGraphmasse.Size = new Size(550, 550);
            pictureBoxGraphmasse.TabIndex = 2;
            pictureBoxGraphmasse.TabStop = false;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(345, 647);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(0, 4);
            listBox1.TabIndex = 3;
            // 
            // labelDateDebut
            // 
            labelDateDebut.AutoSize = true;
            labelDateDebut.Location = new Point(12, 18);
            labelDateDebut.Name = "labelDateDebut";
            labelDateDebut.Size = new Size(28, 15);
            labelDateDebut.TabIndex = 6;
            labelDateDebut.Text = "Du :";
            // 
            // labelDateFin
            // 
            labelDateFin.AutoSize = true;
            labelDateFin.Location = new Point(12, 72);
            labelDateFin.Name = "labelDateFin";
            labelDateFin.Size = new Size(28, 15);
            labelDateFin.TabIndex = 7;
            labelDateFin.Text = "Au :";
            // 
            // dataGridViewPassagesReines
            // 
            dataGridViewPassagesReines.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPassagesReines.Location = new Point(145, 662);
            dataGridViewPassagesReines.Name = "dataGridViewPassagesReines";
            dataGridViewPassagesReines.RowTemplate.Height = 25;
            dataGridViewPassagesReines.Size = new Size(246, 242);
            dataGridViewPassagesReines.TabIndex = 8;
            // 
            // Date
            // 
            Date.HeaderText = "Date/Heure";
            Date.Name = "Date";
            // 
            // Couleur
            // 
            Couleur.HeaderText = "Couleur";
            Couleur.Name = "Couleur";
            // 
            // dataGridViewPosition
            // 
            dataGridViewPosition.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPosition.Columns.AddRange(new DataGridViewColumn[] { Horodatage, Coordonnées });
            dataGridViewPosition.Location = new Point(515, 661);
            dataGridViewPosition.Name = "dataGridViewPosition";
            dataGridViewPosition.RowTemplate.Height = 25;
            dataGridViewPosition.Size = new Size(237, 242);
            dataGridViewPosition.TabIndex = 9;
            // 
            // Horodatage
            // 
            Horodatage.HeaderText = "Date/Heure";
            Horodatage.Name = "Horodatage";
            // 
            // Coordonnées
            // 
            Coordonnées.HeaderText = "Coordonnées";
            Coordonnées.Name = "Coordonnées";
            // 
            // textBoxPosition
            // 
            textBoxPosition.Location = new Point(515, 639);
            textBoxPosition.Name = "textBoxPosition";
            textBoxPosition.Size = new Size(237, 23);
            textBoxPosition.TabIndex = 10;
            textBoxPosition.Text = "Position";
            // 
            // textBoxPassagesReines
            // 
            textBoxPassagesReines.Location = new Point(145, 639);
            textBoxPassagesReines.Name = "textBoxPassagesReines";
            textBoxPassagesReines.Size = new Size(246, 23);
            textBoxPassagesReines.TabIndex = 11;
            textBoxPassagesReines.Text = "Passages Reines";
            // 
            // buttonAppliquer
            // 
            buttonAppliquer.Location = new Point(12, 131);
            buttonAppliquer.Name = "buttonAppliquer";
            buttonAppliquer.Size = new Size(96, 23);
            buttonAppliquer.TabIndex = 12;
            buttonAppliquer.Text = "Appliquer";
            buttonAppliquer.UseVisualStyleBackColor = true;
            buttonAppliquer.Click += button1_Click;
            // 
            // maskedTextBoxDateDebut
            // 
            maskedTextBoxDateDebut.Location = new Point(12, 36);
            maskedTextBoxDateDebut.Mask = "00/00/0000";
            maskedTextBoxDateDebut.Name = "maskedTextBoxDateDebut";
            maskedTextBoxDateDebut.Size = new Size(96, 23);
            maskedTextBoxDateDebut.TabIndex = 15;
            maskedTextBoxDateDebut.ValidatingType = typeof(DateTime);
            // 
            // maskedTextBoxDateFin
            // 
            maskedTextBoxDateFin.Location = new Point(12, 91);
            maskedTextBoxDateFin.Mask = "00/00/0000";
            maskedTextBoxDateFin.Name = "maskedTextBoxDateFin";
            maskedTextBoxDateFin.Size = new Size(96, 23);
            maskedTextBoxDateFin.TabIndex = 16;
            maskedTextBoxDateFin.ValidatingType = typeof(DateTime);
            // 
            // Interface1
            // 
            Controls.Add(maskedTextBoxDateFin);
            Controls.Add(maskedTextBoxDateDebut);
            Controls.Add(buttonAppliquer);
            Controls.Add(textBoxPassagesReines);
            Controls.Add(textBoxPosition);
            Controls.Add(dataGridViewPosition);
            Controls.Add(dataGridViewPassagesReines);
            Controls.Add(labelDateFin);
            Controls.Add(labelDateDebut);
            Controls.Add(listBox1);
            Controls.Add(pictureBoxGraphmasse);
            Controls.Add(pictureBoxGraphHygro);
            Controls.Add(pictureBoxGraphTemperature);
            Name = "Interface1";
            Size = new Size(1880, 988);
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphTemperature).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphHygro).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphmasse).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPassagesReines).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPosition).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private PictureBox pictureBoxGraphTemperature;
        private PictureBox pictureBoxGraphHygro;
        private PictureBox pictureBoxGraphmasse;
        private ListBox listBox1;
        private Label labelDateDebut;
        private Label labelDateFin;
        private DataGridView dataGridViewPassagesReines;
        private DataGridViewTextBoxColumn Date;
        private DataGridViewTextBoxColumn Couleur;
        private DataGridView dataGridViewPosition;
        private DataGridViewTextBoxColumn Horodatage;
        private DataGridViewTextBoxColumn Coordonnées;
        private TextBox textBoxPosition;
        private TextBox textBoxPassagesReines;
        private Button buttonAppliquer;
        private MaskedTextBox maskedTextBoxDateDebut;
        private MaskedTextBox maskedTextBoxDateFin;
    }
}
