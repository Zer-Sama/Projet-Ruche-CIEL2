using System;
using System.Windows.Forms;

namespace ToBeeInControleWinForms{
    public partial class Form1 : Form{
        public Form1(){
            InitializeComponent();
            // Initialement, afficher l'interface 1
            ShowInterface1();
        }

        private void ShowInterface1(){
            InterfaceContainer.Controls.Clear();
            Interface1 interface1 = new Interface1();
            interface1.Dock = DockStyle.Fill;
            InterfaceContainer.Controls.Add(interface1);
        }

        private void ShowInterface2(){
            InterfaceContainer.Controls.Clear();
            Interface2 interface2 = new Interface2();
            interface2.Dock = DockStyle.Fill;
            InterfaceContainer.Controls.Add(interface2);
        }

        private void SwitchToInterface1_Click(object sender, EventArgs e){
            ShowInterface1();
        }

        private void SwitchToInterface2_Click(object sender, EventArgs e){
            ShowInterface2();
        }
    }
}
