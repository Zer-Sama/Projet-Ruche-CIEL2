﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using Npgsql;

namespace ToBeeInControleWinForms
{
    using System.Data;
    using System.IO;
    using System.Runtime.InteropServices;
    public partial class Interface1 : UserControl
    {
        bool canDraw;
        int x;
        int y;
        DateTime[] heure;
        double[] masse;
        string line;
        CControleBDDOPortable ControleurBDD;
        NpgsqlConnection IDStreamBDD;
        NpgsqlDataAdapter table;

        // Chaîne de connexion PostgreSQL 
        //private string connString = "Host=localhost;Port=5432;Username=postgres;Password=Dps8alme;Database=postgres";

        public Interface1()
        {
            InitializeComponent();
            canDraw = false;

            pictureBoxGraphmasse.Paint += new PaintEventHandler(pictureBoxGraphmasse_Paint);
            pictureBoxGraphHygro.Paint += new PaintEventHandler(pictureBoxGraphHygro_Paint);
            pictureBoxGraphTemperature.Paint += new PaintEventHandler(pictureBoxGraphTemperature_Paint);

            maskedTextBoxDateDebut.Text = DateTime.Now.AddDays(-1).ToString("dd/MM/yyyy");
            maskedTextBoxDateFin.Text = DateTime.Now.ToString("dd/MM/yyyy");
            maskedTextBoxDateDebut.Validating += MaskedTextBoxDate_ValidatingDebut;
            maskedTextBoxDateFin.Validating += MaskedTextBoxDate_ValidatingFin;


            try
            {
                // Initialisation du contrôleur BDD
                ControleurBDD = new CControleBDDOPortable();
                IDStreamBDD = ControleurBDD.Connection();
            }
            catch (Exception ex)
            {
                // Gérer l'exception 
                MessageBox.Show($"Erreur lors de la connexion à la base de données : {ex.Message}");
            }

            this.Load += (s, e) => dataGridView2_CellContentClick();

        }



        private void dataGridView2_CellContentClick()
        {
            if (IDStreamBDD != null) {
                string requete = "SELECT heure, couleur FROM constantereine";
                table = ControleurBDD.Lire(requete, IDStreamBDD);
                DataTable dt = new DataTable();
                table.Fill(dt);

                // Vérifier le nombre de lignes récupérées
                if (dt.Rows.Count > 0)
                {
                    dataGridViewPassagesReines.DataSource = dt; // Affichage dans la DataGridView
                }
                else
                {
                    MessageBox.Show("Aucune donnée trouvée.");
                }
            }
            
        }

        private void pictureBoxGraphmasse_Paint(object sender, PaintEventArgs e)
        {
            int i;
            x = 1;
            y = 1;
            Graphics g = e.Graphics;
            Pen crayon_rouge = new Pen(Color.Red);
            Pen crayon_gris = new Pen(Color.Gray);
            Pen crayon_noir = new Pen(Color.Black);
            g.Clear(Color.White);


            // tracé des contoures
            g.DrawLine(crayon_gris, 0, 0, 0, pictureBoxGraphHygro.Height); //contoures haut
            g.DrawLine(crayon_gris, pictureBoxGraphHygro.Width - 1, 0, pictureBoxGraphHygro.Width - 1, pictureBoxGraphHygro.Height - 1);//contoures bat
            g.DrawLine(crayon_gris, 0, 0, pictureBoxGraphHygro.Width, 0);//contoures gauche
            g.DrawLine(crayon_gris, 0, pictureBoxGraphHygro.Height - 1, pictureBoxGraphHygro.Width - 1, pictureBoxGraphHygro.Height - 1);//contoures droit

            // tracé des axes
            g.DrawLine(crayon_noir, 40, pictureBoxGraphHygro.Height - 70, pictureBoxGraphHygro.Width - 16, pictureBoxGraphHygro.Height - 70);// axes des X
            g.DrawLine(crayon_noir, 40, 30, 40, pictureBoxGraphHygro.Height - 70);// axes des Y

            // Ajout des graduations sur l'axe X
            int xInterval = 45; // Intervalle entre les graduations sur l'axe X
            for (i = 40; i < pictureBoxGraphHygro.Width; i += xInterval)
            {
                g.DrawLine(crayon_noir, i, pictureBoxGraphHygro.Height - 70, i, pictureBoxGraphHygro.Height - 65);
            }

            // Ajout des graduations sur l'axe Y
            int yInterval = 45; // Intervalle entre les graduations sur l'axe Y
            for (i = pictureBoxGraphHygro.Height - 70; i > 10; i -= yInterval)
            {
                g.DrawLine(crayon_noir, 35, i, 40, i);
            }

            canDraw = true;

            if (canDraw)
            {
                if (IDStreamBDD != null)
                {
                    string requete = "SELECT heure, masse FROM constantereine";
                    table = ControleurBDD.Lire(requete, IDStreamBDD);
                    DataTable dt = new DataTable();
                    table.Fill(dt);

                    heure = new DateTime[dt.Rows.Count];
                    masse = new double[dt.Rows.Count];
                    double masse_pix=0.222;
                    double heure_pix = 510 / heure.Length;
                    for (int a = 0; a < dt.Rows.Count; a+=2)
                    {
                        heure[a] = Convert.ToDateTime(dt.Rows[a]["heure"]);
                        masse[a] = Convert.ToDouble(dt.Rows[a]["masse"]);
                    }

                    for (i = 0; i < heure.Length; i +=2)
                    {
                        g.DrawLine(crayon_rouge, (float)i * (float)heure_pix, (float)masse[i]/(float)masse_pix, (float)(i+1)*(float)heure_pix, (float)masse[i+1] / (float)masse_pix);

                    }
                        
                }
            }
        }

        private void pictureBoxGraphHygro_Paint(object sender, PaintEventArgs e)
        {
            int i;
            x = 1;
            y = 1;
            Graphics g = e.Graphics;
            Pen crayon_rouge = new Pen(Color.Red);
            Pen crayon_gris = new Pen(Color.Gray);
            Pen crayon_noir = new Pen(Color.Black);
            g.Clear(Color.White);


            // tracé des contoures
            g.DrawLine(crayon_gris, 0, 0, 0, pictureBoxGraphHygro.Height); //contoures haut
            g.DrawLine(crayon_gris, pictureBoxGraphHygro.Width - 1, 0, pictureBoxGraphHygro.Width - 1, pictureBoxGraphHygro.Height - 1);//contoures bat
            g.DrawLine(crayon_gris, 0, 0, pictureBoxGraphHygro.Width, 0);//contoures gauche
            g.DrawLine(crayon_gris, 0, pictureBoxGraphHygro.Height - 1, pictureBoxGraphHygro.Width - 1, pictureBoxGraphHygro.Height - 1);//contoures droit

            // tracé des axes
            g.DrawLine(crayon_noir, 40, pictureBoxGraphHygro.Height - 70, pictureBoxGraphHygro.Width - 16, pictureBoxGraphHygro.Height - 70);// axes des X
            g.DrawLine(crayon_noir, 40, 30, 40, pictureBoxGraphHygro.Height - 70);// axes des Y

            // Ajout des graduations sur l'axe X
            int xInterval = 45; // Intervalle entre les graduations sur l'axe X
            for (i = 40; i < pictureBoxGraphHygro.Width; i += xInterval)
            {
                g.DrawLine(crayon_noir, i, pictureBoxGraphHygro.Height - 70, i, pictureBoxGraphHygro.Height - 65);
            }

            // Ajout des graduations sur l'axe Y
            int yInterval = 45; // Intervalle entre les graduations sur l'axe Y
            for (i = pictureBoxGraphHygro.Height - 70; i > 10; i -= yInterval)
            {
                g.DrawLine(crayon_noir, 35, i, 40, i);
            }



            if (canDraw)
            {
                for (i = 1; i < pictureBoxGraphHygro.Width; i++)
                    g.DrawLine(crayon_rouge, (float)x, (float)y, (float)x, (float)y);
            }



        }

        private void pictureBoxGraphTemperature_Paint(object sender, PaintEventArgs e)
        {
            int i;
            x = 1;
            y = 1;
            Graphics g = e.Graphics;
            Pen crayon_rouge = new Pen(Color.Red);
            Pen crayon_gris = new Pen(Color.Gray);
            Pen crayon_noir = new Pen(Color.Black);
            g.Clear(Color.White);


            // tracé des contoures
            g.DrawLine(crayon_gris, 0, 0, 0, pictureBoxGraphHygro.Height); //contoures haut
            g.DrawLine(crayon_gris, pictureBoxGraphHygro.Width - 1, 0, pictureBoxGraphHygro.Width - 1, pictureBoxGraphHygro.Height - 1);//contoures bat
            g.DrawLine(crayon_gris, 0, 0, pictureBoxGraphHygro.Width, 0);//contoures gauche
            g.DrawLine(crayon_gris, 0, pictureBoxGraphHygro.Height - 1, pictureBoxGraphHygro.Width - 1, pictureBoxGraphHygro.Height - 1);//contoures droit

            // tracé des axes
            g.DrawLine(crayon_noir, 10, pictureBoxGraphTemperature.Height - 10, pictureBoxGraphTemperature.Width - 1, pictureBoxGraphTemperature.Height - 10);
            g.DrawLine(crayon_noir, 10, 0, 10, pictureBoxGraphTemperature.Height - 10);

            // Ajout des graduations sur l'axe X
            int xInterval = 20; // Intervalle entre les graduations sur l'axe X
            for (i = xInterval; i < pictureBoxGraphHygro.Width; i += xInterval)
            {
                g.DrawLine(crayon_noir, i, pictureBoxGraphHygro.Height - 10, i, pictureBoxGraphHygro.Height - 5);
            }

            // Ajout des graduations sur l'axe Y
            int yInterval = 20; // Intervalle entre les graduations sur l'axe Y
            for (i = pictureBoxGraphHygro.Height - 20; i > 10; i -= yInterval)
            {
                g.DrawLine(crayon_noir, 5, i, 10, i);
            }

            if (canDraw)
            {
                for (i = 1; i < pictureBoxGraphTemperature.Width; i++)
                    g.DrawLine(crayon_rouge, (float)x, (float)y, (float)x, (float)y);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Controls.Add(maskedTextBoxDateDebut);
            this.Controls.Add(maskedTextBoxDateFin);
        }
        private void MaskedTextBoxDate_ValidatingDebut(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MaskedTextBox maskedTextBox = sender as MaskedTextBox;
            if (string.IsNullOrWhiteSpace(maskedTextBox.Text) ||
                !DateTime.TryParseExact(maskedTextBox.Text, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out _))
            {
                // Si la date n'est pas valide ou le champ est vide, afficher un message d'erreur
                e.Cancel = true;
                maskedTextBox.Focus();
                MessageBox.Show("Veuillez entrer une date valide au format jj/mm/aaaa.");

                // Remplir avec la date d'hier
                maskedTextBox.Text = DateTime.Now.AddDays(-1).ToString("dd/MM/yyyy");
            }
        }
        private void MaskedTextBoxDate_ValidatingFin(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MaskedTextBox maskedTextBox = sender as MaskedTextBox;
            if (string.IsNullOrWhiteSpace(maskedTextBox.Text) ||
                !DateTime.TryParseExact(maskedTextBox.Text, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out _))
            {
                // Si la date n'est pas valide ou le champ est vide, afficher un message d'erreur
                e.Cancel = true;
                maskedTextBox.Focus();
                MessageBox.Show("Veuillez entrer une date valide au format jj/mm/aaaa.");

                // Remplir avec la date d'hier
                maskedTextBox.Text = DateTime.Now.ToString("dd/MM/yyyy");
            }
        }
    }
}

