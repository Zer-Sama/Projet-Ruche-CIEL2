﻿namespace ToBeeInControleWinForms
{
    partial class Interface2
    {
        private System.ComponentModel.IContainer components = null;

        private void InitializeComponent()
        {
            checkBoxAlerteReine = new CheckBox();
            checkBoxAlerteParametres = new CheckBox();
            labelTemperature = new Label();
            labelHygrometrie = new Label();
            textBoxTemperature = new TextBox();
            textBoxHygrometrie = new TextBox();
            buttonAppliquerParametre = new Button();
            SuspendLayout();
            // 
            // checkBoxAlerteReine
            // 
            checkBoxAlerteReine.AutoSize = true;
            checkBoxAlerteReine.Location = new Point(62, 154);
            checkBoxAlerteReine.Name = "checkBoxAlerteReine";
            checkBoxAlerteReine.Size = new Size(170, 19);
            checkBoxAlerteReine.TabIndex = 0;
            checkBoxAlerteReine.Text = "Alerte de sortie d'une Reine";
            checkBoxAlerteReine.UseVisualStyleBackColor = true;
            // 
            // checkBoxAlerteParametres
            // 
            checkBoxAlerteParametres.AutoSize = true;
            checkBoxAlerteParametres.Location = new Point(62, 179);
            checkBoxAlerteParametres.Name = "checkBoxAlerteParametres";
            checkBoxAlerteParametres.Size = new Size(224, 19);
            checkBoxAlerteParametres.TabIndex = 1;
            checkBoxAlerteParametres.Text = "Alerte de dépassement de paramétres";
            checkBoxAlerteParametres.UseVisualStyleBackColor = true;
            // 
            // labelTemperature
            // 
            labelTemperature.AutoSize = true;
            labelTemperature.Location = new Point(62, 40);
            labelTemperature.Name = "labelTemperature";
            labelTemperature.Size = new Size(99, 15);
            labelTemperature.TabIndex = 2;
            labelTemperature.Text = "Température Max";
            // 
            // labelHygrometrie
            // 
            labelHygrometrie.AutoSize = true;
            labelHygrometrie.Location = new Point(62, 73);
            labelHygrometrie.Name = "labelHygrometrie";
            labelHygrometrie.Size = new Size(101, 15);
            labelHygrometrie.TabIndex = 3;
            labelHygrometrie.Text = "Hygrométrie Mini";
            // 
            // textBoxTemperature
            // 
            textBoxTemperature.Location = new Point(168, 37);
            textBoxTemperature.Name = "textBoxTemperature";
            textBoxTemperature.Size = new Size(134, 23);
            textBoxTemperature.TabIndex = 5;
            textBoxTemperature.KeyPress += textBoxTemperature_KeyPress;
            // 
            // textBoxHygrometrie
            // 
            textBoxHygrometrie.Location = new Point(168, 70);
            textBoxHygrometrie.Name = "textBoxHygrometrie";
            textBoxHygrometrie.Size = new Size(134, 23);
            textBoxHygrometrie.TabIndex = 6;
            textBoxHygrometrie.KeyPress += textBoxHygrometrie_KeyPress;
            // 
            // buttonAppliquerParametre
            // 
            buttonAppliquerParametre.BackColor = Color.Transparent;
            buttonAppliquerParametre.FlatStyle = FlatStyle.Popup;
            buttonAppliquerParametre.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buttonAppliquerParametre.Location = new Point(62, 236);
            buttonAppliquerParametre.Name = "buttonAppliquerParametre";
            buttonAppliquerParametre.Size = new Size(95, 34);
            buttonAppliquerParametre.TabIndex = 8;
            buttonAppliquerParametre.Text = "Appliquer";
            buttonAppliquerParametre.UseVisualStyleBackColor = false;
            buttonAppliquerParametre.Click += buttonAppliquerParametre_Click;
            // 
            // Interface2
            // 
            Controls.Add(buttonAppliquerParametre);
            Controls.Add(textBoxHygrometrie);
            Controls.Add(textBoxTemperature);
            Controls.Add(labelHygrometrie);
            Controls.Add(labelTemperature);
            Controls.Add(checkBoxAlerteParametres);
            Controls.Add(checkBoxAlerteReine);
            Name = "Interface2";
            Size = new Size(1242, 521);
            ResumeLayout(false);
            PerformLayout();
        }

        private CheckBox checkBoxAlerteReine;
        private CheckBox checkBoxAlerteParametres;
        private Label labelTemperature;
        private Label labelHygrometrie;
        private TextBox textBoxTemperature;
        private TextBox textBoxHygrometrie;
        private Button buttonAppliquerParametre;
    }
}
