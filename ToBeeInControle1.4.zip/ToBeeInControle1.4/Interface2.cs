﻿using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ToBeeInControleWinForms
{
    public partial class Interface2 : UserControl
    {
        public Interface2()
        {
            InitializeComponent();
        }

        private void buttonAppliquerParametre_Click(object sender, EventArgs e)
        {
            // Récupération des nouveau parametre des TextBox.
            string userInputTemperature = textBoxTemperature.Text;
            string userInputHygrometrie = textBoxHygrometrie.Text;

        }
        private void textBoxTemperature_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Vérifier si le caractère saisi est un chiffre ou une touche de contrôle (comme la touche de suppression)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ignorer le caractère si ce n'est pas un chiffre
            }
        }
        private void textBoxHygrometrie_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Vérifier si le caractère saisi est un chiffre ou une touche de contrôle (comme la touche de suppression)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ignorer le caractère si ce n'est pas un chiffre
            }
        }
    }
}
