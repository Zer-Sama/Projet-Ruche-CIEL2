﻿namespace ToBeeInControleWinForms
{
    partial class Interface1
    {
        private System.ComponentModel.IContainer components = null;

        private void InitializeComponent()
        {
            pictureBoxGraphTemperature = new PictureBox();
            pictureBoxGraphHygro = new PictureBox();
            pictureBoxGraphmasse = new PictureBox();
            listBox1 = new ListBox();
            numericUpDownDateDebut = new NumericUpDown();
            numericUpDownDateFin = new NumericUpDown();
            labelDateDebut = new Label();
            labelDateFin = new Label();
            dataGridViewPassagesReines = new DataGridView();
            Date = new DataGridViewTextBoxColumn();
            Couleur = new DataGridViewTextBoxColumn();
            dataGridViewPosition = new DataGridView();
            Horodatage = new DataGridViewTextBoxColumn();
            Coordonnées = new DataGridViewTextBoxColumn();
            textBoxPosition = new TextBox();
            textBoxPassagesReines = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphTemperature).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphHygro).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphmasse).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownDateDebut).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownDateFin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPassagesReines).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPosition).BeginInit();
            SuspendLayout();
            // 
            // pictureBoxGraphTemperature
            // 
            pictureBoxGraphTemperature.Location = new Point(132, 32);
            pictureBoxGraphTemperature.Name = "pictureBoxGraphTemperature";
            pictureBoxGraphTemperature.Size = new Size(500, 500);
            pictureBoxGraphTemperature.TabIndex = 0;
            pictureBoxGraphTemperature.TabStop = false;
            // 
            // pictureBoxGraphHygro
            // 
            pictureBoxGraphHygro.Location = new Point(739, 32);
            pictureBoxGraphHygro.Name = "pictureBoxGraphHygro";
            pictureBoxGraphHygro.Size = new Size(500, 500);
            pictureBoxGraphHygro.TabIndex = 1;
            pictureBoxGraphHygro.TabStop = false;
            // 
            // pictureBoxGraphmasse
            // 
            pictureBoxGraphmasse.Location = new Point(1351, 32);
            pictureBoxGraphmasse.Name = "pictureBoxGraphmasse";
            pictureBoxGraphmasse.Size = new Size(500, 500);
            pictureBoxGraphmasse.TabIndex = 2;
            pictureBoxGraphmasse.TabStop = false;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(332, 570);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(0, 4);
            listBox1.TabIndex = 3;
            // 
            // numericUpDownDateDebut
            // 
            numericUpDownDateDebut.Location = new Point(12, 36);
            numericUpDownDateDebut.Name = "numericUpDownDateDebut";
            numericUpDownDateDebut.Size = new Size(77, 23);
            numericUpDownDateDebut.TabIndex = 4;
            // 
            // numericUpDownDateFin
            // 
            numericUpDownDateFin.Location = new Point(12, 90);
            numericUpDownDateFin.Name = "numericUpDownDateFin";
            numericUpDownDateFin.Size = new Size(77, 23);
            numericUpDownDateFin.TabIndex = 5;
            // 
            // labelDateDebut
            // 
            labelDateDebut.AutoSize = true;
            labelDateDebut.Location = new Point(12, 18);
            labelDateDebut.Name = "labelDateDebut";
            labelDateDebut.Size = new Size(28, 15);
            labelDateDebut.TabIndex = 6;
            labelDateDebut.Text = "Du :";
            // 
            // labelDateFin
            // 
            labelDateFin.AutoSize = true;
            labelDateFin.Location = new Point(12, 72);
            labelDateFin.Name = "labelDateFin";
            labelDateFin.Size = new Size(28, 15);
            labelDateFin.TabIndex = 7;
            labelDateFin.Text = "Au :";
            // 
            // dataGridViewPassagesReines
            // 
            dataGridViewPassagesReines.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPassagesReines.Columns.AddRange(new DataGridViewColumn[] { Date, Couleur });
            dataGridViewPassagesReines.Location = new Point(132, 585);
            dataGridViewPassagesReines.Name = "dataGridViewPassagesReines";
            dataGridViewPassagesReines.RowTemplate.Height = 25;
            dataGridViewPassagesReines.Size = new Size(246, 242);
            dataGridViewPassagesReines.TabIndex = 8;
            // 
            // Date
            // 
            Date.HeaderText = "Date/Heure";
            Date.Name = "Date";
            // 
            // Couleur
            // 
            Couleur.HeaderText = "Couleur";
            Couleur.Name = "Couleur";
            // 
            // dataGridViewPosition
            // 
            dataGridViewPosition.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPosition.Columns.AddRange(new DataGridViewColumn[] { Horodatage, Coordonnées });
            dataGridViewPosition.Location = new Point(502, 584);
            dataGridViewPosition.Name = "dataGridViewPosition";
            dataGridViewPosition.RowTemplate.Height = 25;
            dataGridViewPosition.Size = new Size(237, 242);
            dataGridViewPosition.TabIndex = 9;
            dataGridViewPosition.CellContentClick += dataGridView2_CellContentClick;
            // 
            // Horodatage
            // 
            Horodatage.HeaderText = "Date/Heure";
            Horodatage.Name = "Horodatage";
            // 
            // Coordonnées
            // 
            Coordonnées.HeaderText = "Coordonnées";
            Coordonnées.Name = "Coordonnées";
            // 
            // textBoxPosition
            // 
            textBoxPosition.Location = new Point(502, 562);
            textBoxPosition.Name = "textBoxPosition";
            textBoxPosition.Size = new Size(237, 23);
            textBoxPosition.TabIndex = 10;
            textBoxPosition.Text = "Position";
            // 
            // textBoxPassagesReines
            // 
            textBoxPassagesReines.Location = new Point(132, 562);
            textBoxPassagesReines.Name = "textBoxPassagesReines";
            textBoxPassagesReines.Size = new Size(246, 23);
            textBoxPassagesReines.TabIndex = 11;
            textBoxPassagesReines.Text = "Passages Reines";
            // 
            // Interface1
            // 
            Controls.Add(textBoxPassagesReines);
            Controls.Add(textBoxPosition);
            Controls.Add(dataGridViewPosition);
            Controls.Add(dataGridViewPassagesReines);
            Controls.Add(labelDateFin);
            Controls.Add(labelDateDebut);
            Controls.Add(numericUpDownDateFin);
            Controls.Add(numericUpDownDateDebut);
            Controls.Add(listBox1);
            Controls.Add(pictureBoxGraphmasse);
            Controls.Add(pictureBoxGraphHygro);
            Controls.Add(pictureBoxGraphTemperature);
            Name = "Interface1";
            Size = new Size(1880, 988);
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphTemperature).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphHygro).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGraphmasse).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownDateDebut).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownDateFin).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPassagesReines).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPosition).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private PictureBox pictureBoxGraphTemperature;
        private PictureBox pictureBoxGraphHygro;
        private PictureBox pictureBoxGraphmasse;
        private ListBox listBox1;
        private NumericUpDown numericUpDownDateDebut;
        private NumericUpDown numericUpDownDateFin;
        private Label labelDateDebut;
        private Label labelDateFin;
        private DataGridView dataGridViewPassagesReines;
        private DataGridViewTextBoxColumn Date;
        private DataGridViewTextBoxColumn Couleur;
        private DataGridView dataGridViewPosition;
        private DataGridViewTextBoxColumn Horodatage;
        private DataGridViewTextBoxColumn Coordonnées;
        private TextBox textBoxPosition;
        private TextBox textBoxPassagesReines;
    }
}
