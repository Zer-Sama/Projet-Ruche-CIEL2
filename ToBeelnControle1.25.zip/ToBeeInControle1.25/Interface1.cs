﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ToBeeInControleWinForms
{
    using System.IO;
    using System.Runtime.InteropServices;
    public partial class Interface1 : UserControl
    {
        bool canDraw;
        int x;
        int y;
        //double[,] tableau;
        //string[] values;
        string line;


        public Interface1()
        {
            InitializeComponent();
            canDraw = false;
            pictureBoxGraphmasse.Paint += new PaintEventHandler(pictureBoxGraphmasse_Paint);
            pictureBoxGraphHygro.Paint += new PaintEventHandler(pictureBoxGraphHygro_Paint);
            pictureBoxGraphTemperature.Paint += new PaintEventHandler(pictureBoxGraphTemperature_Paint);



        }



        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBoxGraphmasse_Paint(object sender, PaintEventArgs e)
        {
            int i;
            x = 1;
            y = 1;
            Graphics g = e.Graphics;
            Pen crayon_rouge = new Pen(Color.Red);
            Pen crayon_noir = new Pen(Color.Black);
            g.Clear(Color.White);


            // tracé des contoures
            g.DrawLine(crayon_noir, 0, 0, 0, pictureBoxGraphmasse.Height);
            g.DrawLine(crayon_noir, pictureBoxGraphmasse.Width - 1, 0, pictureBoxGraphmasse.Width - 1, pictureBoxGraphmasse.Height - 1);
            g.DrawLine(crayon_noir, 0, 0, pictureBoxGraphmasse.Width, 0);
            g.DrawLine(crayon_noir, 0, pictureBoxGraphmasse.Height - 1, pictureBoxGraphmasse.Width - 1, pictureBoxGraphmasse.Height - 1);

            // tracé des axes
            g.DrawLine(crayon_noir, 10, pictureBoxGraphmasse.Height - 10, pictureBoxGraphmasse.Width - 1, pictureBoxGraphmasse.Height - 10);
            g.DrawLine(crayon_noir, 10, 0, 10, pictureBoxGraphmasse.Height - 10);

            if (canDraw)
            {
                for (i = 1; i < pictureBoxGraphmasse.Width; i++)
                    g.DrawLine(crayon_rouge, (float)x, (float)y, (float)x, (float)y);
            }
        }

        private void pictureBoxGraphHygro_Paint(object sender, PaintEventArgs e)
        {
            int i;
            x = 1;
            y = 1;
            Graphics g = e.Graphics;
            Pen crayon_rouge = new Pen(Color.Red);
            Pen crayon_noir = new Pen(Color.Black);
            g.Clear(Color.White);


            // tracé des contoures
            g.DrawLine(crayon_noir, 0, 0, 0, pictureBoxGraphHygro.Height);
            g.DrawLine(crayon_noir, pictureBoxGraphHygro.Width - 1, 0, pictureBoxGraphHygro.Width - 1, pictureBoxGraphHygro.Height - 1);
            g.DrawLine(crayon_noir, 0, 0, pictureBoxGraphHygro.Width, 0);
            g.DrawLine(crayon_noir, 0, pictureBoxGraphHygro.Height - 1, pictureBoxGraphHygro.Width - 1, pictureBoxGraphHygro.Height - 1);

            // tracé des axes
            g.DrawLine(crayon_noir, 20, pictureBoxGraphHygro.Height - 20, pictureBoxGraphHygro.Width - 1, pictureBoxGraphHygro.Height - 20);
            g.DrawLine(crayon_noir, 20, 0, 20, pictureBoxGraphHygro.Height - 20);

            // Ajout des graduations sur l'axe X
            int xInterval = 20; // Intervalle entre les graduations sur l'axe X
            for (i = xInterval; i < pictureBoxGraphHygro.Width; i += xInterval)
            {
                g.DrawLine(crayon_noir, i, pictureBoxGraphHygro.Height - 10, i, pictureBoxGraphHygro.Height - 5);
            }

            // Ajout des graduations sur l'axe Y
            int yInterval = 20; // Intervalle entre les graduations sur l'axe Y
            for (i = pictureBoxGraphHygro.Height - 20; i > 10; i -= yInterval)
            {
                g.DrawLine(crayon_noir, 5, i, 10, i);
            }



            if (canDraw)
            {
                for (i = 1; i < pictureBoxGraphHygro.Width; i++)
                    g.DrawLine(crayon_rouge, (float)x, (float)y, (float)x, (float)y);





            }



        }

        private void pictureBoxGraphTemperature_Paint(object sender, PaintEventArgs e)
        {
            int i;
            x = 1;
            y = 1;
            Graphics g = e.Graphics;
            Pen crayon_rouge = new Pen(Color.Red);
            Pen crayon_noir = new Pen(Color.Black);
            g.Clear(Color.White);


            // tracé des contoures
            g.DrawLine(crayon_noir, 0, 0, 0, pictureBoxGraphTemperature.Height);
            g.DrawLine(crayon_noir, pictureBoxGraphTemperature.Width - 1, 0, pictureBoxGraphTemperature.Width - 1, pictureBoxGraphTemperature.Height - 1);
            g.DrawLine(crayon_noir, 0, 0, pictureBoxGraphTemperature.Width, 0);
            g.DrawLine(crayon_noir, 0, pictureBoxGraphTemperature.Height - 1, pictureBoxGraphTemperature.Width - 1, pictureBoxGraphTemperature.Height - 1);

            // tracé des axes
            g.DrawLine(crayon_noir, 10, pictureBoxGraphTemperature.Height - 10, pictureBoxGraphTemperature.Width - 1, pictureBoxGraphTemperature.Height - 10);
            g.DrawLine(crayon_noir, 10, 0, 10, pictureBoxGraphTemperature.Height - 10);

            if (canDraw)
            {
                for (i = 1; i < pictureBoxGraphTemperature.Width; i++)
                    g.DrawLine(crayon_rouge, (float)x, (float)y, (float)x, (float)y);
            }
        }
    }
}

