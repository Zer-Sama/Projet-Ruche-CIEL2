///////////////////////////////////////////////////////////
//  CGPIO.cpp
//  Implementation of the Class CGPIO
//  Created on:      26-mars-2025 15:05:34
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CGPIO.h"


CGPIO::CGPIO(){

}



CGPIO::~CGPIO(){

}





double CGPIO::Lire(){

	return 0;
}