///////////////////////////////////////////////////////////
//  CDecrypte.h
//  Implementation of the Class CDecrypte
//  Created on:      26-mars-2025 15:05:33
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#if !defined(EA_DDD771E3_F409_4cd5_A0BC_C0F8CF56BEE5__INCLUDED_)
#define EA_DDD771E3_F409_4cd5_A0BC_C0F8CF56BEE5__INCLUDED_

class CDecrypte
{

public:
	CDecrypte();
	virtual ~CDecrypte();

};
#endif // !defined(EA_DDD771E3_F409_4cd5_A0BC_C0F8CF56BEE5__INCLUDED_)
