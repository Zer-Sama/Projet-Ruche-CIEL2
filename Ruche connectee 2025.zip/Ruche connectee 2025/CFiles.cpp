///////////////////////////////////////////////////////////
//  CFiles.cpp
//  Implementation of the Class CFiles
//  Created on:      26-mars-2025 15:05:34
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CFiles.h"
#include <iostream>
#include <fstream>
using namespace std;

CFiles::CFiles():IDStream(-1) {

}



CFiles::~CFiles() {
	
}





void CFiles::ecrire(int IDStream){

}


void CFiles::fermer(int IDStream){

	
}


void CFiles::lire(int IDStraem){
    ifstream file(FileName);
    if (file.is_open()) {
        string line;
        while (getline(file, line)) {
            std::cout << line << std::endl;
        }
        file.close();
    }
    else {
        std::cerr << "Impossible d'ouvrir le fichier pour la lecture." << std::endl;
    }
}



void CFiles::ouvrir(string FileName){
    this->FileName = FileName;
    ifstream file(FileName);
    if (file.is_open()) {
        std::cout << "Fichier ouvert avec succ�s." << std::endl;
        file.close();
    }
    else {
        std::cerr << "Impossible d'ouvrir le fichier." << std::endl;
    }
	 
}