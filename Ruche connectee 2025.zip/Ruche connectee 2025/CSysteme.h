///////////////////////////////////////////////////////////
//  CSysteme.h
//  Implementation of the Class CSysteme
//  Created on:      26-mars-2025 15:05:35
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#if !defined(EA_66810725_71FC_4ecc_9432_505B2075A971__INCLUDED_)
#define EA_66810725_71FC_4ecc_9432_505B2075A971__INCLUDED_

#include "CAlerter.h"
#include "CDecrypte.h"
#include "CFiles.h"

class CSysteme
{

public:
	CSysteme();
	~CSysteme();
	int IDStream;
	CAlerter *m_CAlerter;
	CDecrypte *m_CDecrypte;
	CFiles *m_CFiles;

	bool comparer();
	void Ecrire();
	void ModifierParametre();
	int  TraitementRequete();

private:
	double HygrometrieRef;
	double MasseRef;
	double TemperatureRef;

	
	

};
#endif // !defined(EA_66810725_71FC_4ecc_9432_505B2075A971__INCLUDED_)
