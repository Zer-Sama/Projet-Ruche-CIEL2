///////////////////////////////////////////////////////////
//  CSysteme.cpp
//  Implementation of the Class CSysteme
//  Created on:      26-mars-2025 15:05:35
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CSysteme.h"


CSysteme::CSysteme(){

}



CSysteme::~CSysteme(){

}








bool CSysteme::comparer(){

	return  NULL;
}





void CSysteme::Ecrire(){

}


void CSysteme::ModifierParametre(){

}


int  CSysteme::TraitementRequete(){

	return  NULL;
}