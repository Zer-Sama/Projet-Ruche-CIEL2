#include <iostream>
#include <hx711/common.h>
#include <sstream>
#include <cctype>

int main() {

  using namespace HX711;
  using namespace std;

  // create a SimpleHX711 object using GPIO pin 2 as the data pin,
  // GPIO pin 3 as the clock pin, -370 as the reference unit, and
  // -367471 as the offset
  SimpleHX711 hx(5, 6, 20782, 91416);

  // constantly output weights using the median of 35 samples
  for(;;){
  Mass masse = hx.weight(25);
  float poids = masse.getValue();
  cout << poids << endl;
  };

  return 0;

}
