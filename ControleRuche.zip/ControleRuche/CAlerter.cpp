///////////////////////////////////////////////////////////
//  CAlerter.cpp
//  Implementation of the Class CAlerter
//  Created on:      26-mars-2025 15:05:33
//  Original author: Utilisateur
///////////////////////////////////////////////////////////

#include "CAlerter.h"
//#include <serialport.h>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include <string>

using namespace std;

CAlerter::CAlerter(const string& port, unsigned int baudrate) {
    
}

CAlerter::~CAlerter(){
	
}

bool CAlerter::connecter(){
   return false;
}

void CAlerter::deconnecter() {
	
}

bool CAlerter::ecrire(double DonneesCapteur, char DonneesCamera){
    return false;
}

void CAlerter::RecupNumTel() {

}
