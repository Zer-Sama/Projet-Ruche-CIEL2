﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Data;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Windows.Forms.DataVisualization.Charting;

namespace ToBeeInControleWinForms
{
   
    public partial class Interface1 : UserControl
    {
        bool canDraw;
        int x;
        string format = "dd/MM/yyyy";



        public Interface1()
        {
            InitializeComponent();

            canDraw = false;

            pictureBoxGraphmasse_Paint();
            pictureBoxGraphHygro_Paint();
            pictureBoxGraphTemperature_Paint();

            this.Load += (s, e) => dataGridViewPassageReine();
            this.Load += (s, e) => dataGridViewPositions();

            
        }



        private void dataGridViewPassageReine()
        {
            string[] couleur = Form1.GetDATACouleur();
            DateTime[] heure = Form1.GetDATAHeureReine();

            if (couleur != null && couleur.Length > 0 && heure != null && heure.Length > 0)
            {
                if (couleur.Length == heure.Length)
                {
                    var DataList = couleur.Select((c , index) => new { Couleur = c, Heure = heure[index] }).ToList();
                    dataGridViewPassagesReines.DataSource = DataList;
                }
            }
            else
            {
                MessageBox.Show("Aucune donnée trouvée.");
            }
        }

        private void dataGridViewPositions()
        {
            string[] localisation = Form1.GetDATAPosition();
            if (localisation != null && localisation.Length > 0)
            {
                var localisationList = localisation.Select(c => new { Localisation = c }).ToList();
                dataGridViewPosition.DataSource = localisationList;

                dataGridViewPosition.Columns["Localisation"].Width = 200;
            }
            else
            {
                MessageBox.Show("Aucune donnée trouvée.");
            }

        }

        private void pictureBoxGraphmasse_Paint()
        {
            pictureBoxGraphmasse.Series.Clear();
            pictureBoxGraphmasse.ChartAreas.Clear();
            ChartArea chartArea= new ChartArea("MasseArea");
            pictureBoxGraphmasse.ChartAreas.Add(chartArea);
            double[] masse = Form1.GetDATAMasse();

            Series series = new Series("masse");
            for (int i=1 ; i< masse.Length;i++)
            {
                series.Points.AddXY(i,masse[i]);
            }

            series.ChartType = SeriesChartType.Line;
            pictureBoxGraphmasse.Series.Add(series);

        }

        private void pictureBoxGraphHygro_Paint()
        {
            double[] hygrometrie = Form1.GetDATAHygrometrie();
            pictureBoxGraphHygro.Series.Clear();
            pictureBoxGraphHygro.ChartAreas.Clear();
            ChartArea chartArea = new ChartArea("HygroArea");
            pictureBoxGraphHygro.ChartAreas.Add(chartArea);

            Series series = new Series("hygrometrie");
            for (int i = 1; i < hygrometrie.Length; i++)
            {
                series.Points.AddXY(i, hygrometrie[i]);
            }

            series.ChartType = SeriesChartType.Line;

            pictureBoxGraphHygro.Series.Add(series);
        }

        private void pictureBoxGraphTemperature_Paint()
        {
            double[] temperature = Form1.GetDATATemperature();
            pictureBoxGraphTemperature.Series.Clear();
            pictureBoxGraphTemperature.ChartAreas.Clear();
            ChartArea chartArea = new ChartArea("TempArea");
            pictureBoxGraphTemperature.ChartAreas.Add(chartArea);

            Series series = new Series("temperature");
            for (int i = 1; i < temperature.Length; i++)
            {
                series.Points.AddXY(i, temperature[i]);
            }

            series.ChartType = SeriesChartType.Line;

            pictureBoxGraphTemperature.Series.Add(series);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Form1.inputDateDebut = DateTime.ParseExact(maskedTextBoxDateDebut.Text, format, CultureInfo.InvariantCulture);
            Form1.inputDateFin = DateTime.ParseExact(maskedTextBoxDateFin.Text, format, CultureInfo.InvariantCulture);

            Form1.DateDebut1 = $"{Form1.inputDateDebut.ToString("yyyy-MM-dd")}";
            Form1.DateFin1 = $"{Form1.inputDateFin.ToString("yyyy-MM-dd")}";

            Form1.DateDebut = $"{Form1.inputDateDebut.ToString("dd-MM-yyyy")}";
            Form1.DateFin = $"{Form1.inputDateFin.ToString("dd-MM-yyyy")}";

            Form1.LireBDD();

            pictureBoxGraphTemperature_Paint();
            pictureBoxGraphHygro_Paint();
            pictureBoxGraphmasse_Paint();
            dataGridViewPositions();
            dataGridViewPassageReine();
        }

        public void MaskedTextBoxDate_ValidatingDebut(object sender, System.ComponentModel.CancelEventArgs e, string datedebutdefaut)
        {
             MaskedTextBox? maskedTextBox = sender as MaskedTextBox;
            if (string.IsNullOrWhiteSpace(maskedTextBox.Text) || !DateTime.TryParseExact(maskedTextBox.Text, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out _))
            {
                // Si la date n'est pas valide ou le champ est vide, afficher un message d'erreur
                e.Cancel = true;
                maskedTextBox.Focus();
                MessageBox.Show("Veuillez entrer une date valide au format jj/mm/aaaa.");

                // Remplir avec la date d'hier
                maskedTextBox.Text = DateTime.Now.AddDays(-1).ToString("dd/MM/yyyy");
            }
            else
            {
                Form1.DateDebut = datedebutdefaut;
            }
        }
        public void MaskedTextBoxDate_ValidatingFin(object sender, System.ComponentModel.CancelEventArgs e, string datefintdefaut)
        {
            MaskedTextBox? maskedTextBox = sender as MaskedTextBox;
            if (string.IsNullOrWhiteSpace(maskedTextBox.Text) || !DateTime.TryParseExact(maskedTextBox.Text, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out _))
            {
                // Si la date n'est pas valide ou le champ est vide, afficher un message d'erreur
                e.Cancel = true;
                maskedTextBox.Focus();
                MessageBox.Show("Veuillez entrer une date valide au format jj/mm/aaaa.");

                // Remplir avec la date d'hier
                maskedTextBox.Text = DateTime.Now.ToString("dd/MM/yyyy");
            }
            else
            {
                Form1.DateFin = datefintdefaut;
            }
        }
    }
}

