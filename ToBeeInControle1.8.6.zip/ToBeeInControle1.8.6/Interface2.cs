﻿using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace ToBeeInControleWinForms
{
    public partial class Interface2 : UserControl
    {
        
        public Interface2()
        {
            InitializeComponent();
            AffichageParametre();
        }

        private void buttonAppliquerParametre_Click(object sender, EventArgs e)
        {
            // Récupération des nouveau parametre des TextBox.
            string userInputTemperature = textBoxTemperature.Text;
            string userInputHygrometrie = textBoxHygrometrie.Text;

            string CheckBoxAlerteReine;
            string CheckBoxAlerteParametres;
            

            if (checkBoxAlerteReine.Checked)
            {
                CheckBoxAlerteReine = "true";
            }
            else {
                CheckBoxAlerteReine = "false";
            }
            if (checkBoxAlerteParametres.Checked)
            {
                CheckBoxAlerteParametres = "true";
            }
            else
            {
                CheckBoxAlerteParametres = "false";
            }

            string path = "C:\\Users\\Utilisateur\\Desktop\\projet Ruche Connecter\\ToBeeInControle1.8\\parametreruche.txt";
            string content = $"{userInputTemperature};{userInputHygrometrie};{CheckBoxAlerteReine};{CheckBoxAlerteParametres}";

            // Utilisation de File.WriteAllText pour écrire dans un fichier
            File.WriteAllText(path, content);

            Form1.EcrireSFTP();

        }
        private void textBoxTemperature_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Vérifier si le caractère saisi est un chiffre ou une touche de contrôle (comme la touche de suppression)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ignorer le caractère si ce n'est pas un chiffre
            }
        }
        private void textBoxHygrometrie_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Vérifier si le caractère saisi est un chiffre ou une touche de contrôle (comme la touche de suppression)
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true; // Ignorer le caractère si ce n'est pas un chiffre
            }
        }

        private void AffichageParametre()
        {
            // Chemin du fichier à lire
            string cheminfichier = "parametreruche.txt";
            string[] parametre;

            try
            {
                // Lire tout le contenu du fichier
                string fichierparametre = File.ReadAllText(cheminfichier);

                // Diviser le contenu en utilisant le point-virgule comme séparateur
                parametre = fichierparametre.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

                // Ecrir les parametre dans les textebox
                textBoxTemperature.Text = parametre[0];
                textBoxHygrometrie.Text = parametre[1];

                // Modifier les CheckBox
                bool checkBox1Value = parametre[2]=="true";
                bool checkBox2Value = parametre[3] == "true";

                checkBoxAlerteParametres.Checked = checkBox1Value;
                checkBoxAlerteReine.Checked = checkBox2Value;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Une erreur s'est produite a la création du fichier : " + ex.Message);
            }
        }
        
    }
}
