using MySql.Data.MySqlClient;
using System;
using System.Globalization;
using System.Windows.Forms;
using Renci.SshNet;

namespace ToBeeInControleWinForms{
    public partial class Form1 : Form{

        static CClientOPortable? cclientOportable;
        private static CControleBDDOPortable? ControleurBDD;
        static DATA data;

        public static string DateDebut = DateTime.Now.AddDays(-1).ToString("dd/MM/yyyy");//format affichage
        public static string DateFin= DateTime.Now.ToString("dd/MM/yyyy");//format affichage
        public static string DateDebut1 = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");//format commande MYSQL
        public static string DateFin1 = DateTime.Now.ToString("yyyy-MM-dd");//format commande MYSQL
        public static DateTime inputDateDebut;  //date de debut format DateTime
        public static DateTime inputDateFin;    //date de fin format DateTime

        public static int TemperatureUtilisateur;
        public static int HygrometrieUtilisateur;

        string format = "dd/MM/yyyy"; //format pour la convertion Date*** en Date***1

         public Form1(){
            InitializeComponent();
            ControleurBDD = new CControleBDDOPortable();
            cclientOportable = new CClientOPortable();
            data = new DATA();
            ControleurBDD.Connection();
            cclientOportable.Connection();
            LireBDD();
            
            // Initialement, afficher l'interface 1
            ShowInterface1();

            
        }

        private void ShowInterface1()
        {
            InterfaceContainer.Controls.Clear();
            Interface1 interface1 = new Interface1();
            interface1.Dock = DockStyle.Fill;
            InterfaceContainer.Controls.Add(interface1);

            interface1.maskedTextBoxDateDebut.Text = DateDebut;
            interface1.maskedTextBoxDateFin.Text = DateFin;

            string datedebutdefaut = interface1.maskedTextBoxDateDebut.Text;
            string datefintdefaut = interface1.maskedTextBoxDateFin.Text;

            datedebutdefaut += interface1.MaskedTextBoxDate_ValidatingDebut;
            datefintdefaut += interface1.MaskedTextBoxDate_ValidatingFin;

            inputDateDebut = DateTime.ParseExact(interface1.maskedTextBoxDateDebut.Text, format, CultureInfo.InvariantCulture);
            inputDateFin = DateTime.ParseExact(interface1.maskedTextBoxDateFin.Text, format, CultureInfo.InvariantCulture);

            DateDebut1 = $"{inputDateDebut.ToString("yyyy-MM-dd")}";
            DateFin1 = $"{inputDateFin.ToString("yyyy-MM-dd")}";
        }

        private void ShowInterface2()
        {
            InterfaceContainer.Controls.Clear();
            Interface2 interface2 = new Interface2();
            interface2.Dock = DockStyle.Fill;
            InterfaceContainer.Controls.Add(interface2);
        }

        private void SwitchToInterface1_Click(object sender, EventArgs e)
        {
            ShowInterface1();
        }

        private void SwitchToInterface2_Click(object sender, EventArgs e)
        {
            ShowInterface2();
        }

        public void EcrireBDD(string requete, MySqlConnection IDStreamBDD)
        {
        
        }

        public static void LireBDD()
        {
            data = ControleurBDD.Lire(DateDebut1,DateFin1);

            if (data.couleur == null || data.couleur.Length == 0)
            {
                MessageBox.Show("Aucune donn�e de couleur trouv�e.");
            }

            if (data.localisation == null || data.localisation.Length == 0)
            {
                MessageBox.Show("Aucune donn�e de localisation trouv�e.");
            }
        }

        public static void EcrireSFTP()
        {
            cclientOportable.Ecrire();
        }

        public static double[] GetDATATemperature() {
            return data.temperature;
        }
        public static double[] GetDATAHygrometrie()
        {
            return data.hygrometrie;
        }
        public static double[] GetDATAMasse()
        {
            return data.masse;
        }
        public static DateTime[] GetDATAHeureRuche()
        {
            return data.heureruche;
        }
        public static DateTime[] GetDATAHeureReine()
        {
            return data.heurereine;
        }
        public static string[] GetDATACouleur()
        {
            return data.couleur;
        }
        public static string[] GetDATAPosition()
        {
            return data.localisation;
        }

    }
}
