#include "CGestioCame.h"
#include <iostream>
#include <thread>

using namespace std;

void Camera()
{
        CGestioCame Camera;
        Camera.PrendreUnePhoto();
}

int main()
{
    thread Boucle(Camera);
    Boucle.join();
    /*CGestioCame Camera;
    Camera.PrendreUnePhoto();*/
}